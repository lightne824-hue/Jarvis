import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import httpx
from .config import settings
from .db import db_session
from .schemas import ChatRequest, ChatResponse, TaskCreate, NoteCreate, MemoryCreate, ToolRequest
from .llm import chat
from .tools import execute_tool, ToolError

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
logger = logging.getLogger("jarvis")
app = FastAPI(title="JARVIS API", version="0.1.0", description="Personal AI assistant orchestration API")
app.add_middleware(CORSMiddleware, allow_origins=settings.allowed_origins, allow_credentials=False, allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Content-Type", "Authorization"])


@app.get("/health")
def health():
    return {"status": "ok", "service": "jarvis-api", "llm_configured": bool(settings.groq_api_key), "mode": "live" if settings.groq_api_key else "demo"}

@app.post("/api/chat", response_model=ChatResponse)
async def chat_endpoint(request: ChatRequest):
    with db_session() as db:
        db.execute("INSERT INTO conversations(role,content) VALUES('user',?)", (request.message,))
    try:
        reply, provider, actions = await chat(request.message, [m.model_dump() for m in request.history])
    except httpx.HTTPStatusError as exc:
        logger.warning("LLM provider returned HTTP %s", exc.response.status_code)
        raise HTTPException(status_code=502, detail="The AI provider returned an error. Check the server-side key, model access, and provider status.") from exc
    except httpx.HTTPError as exc:
        logger.warning("LLM provider network error: %s", type(exc).__name__)
        raise HTTPException(status_code=504, detail="The AI provider could not be reached before timeout.") from exc
    with db_session() as db:
        db.execute("INSERT INTO conversations(role,content) VALUES('assistant',?)", (reply,))
    return ChatResponse(reply=reply, provider=provider, mode="demo" if provider == "demo" else "live", actions=actions)

@app.get("/api/conversations")
def conversations(limit: int = 50):
    limit = max(1, min(limit, 200))
    with db_session() as db:
        rows = db.execute("SELECT id,role,content,created_at FROM conversations ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return {"items": [dict(r) for r in reversed(rows)]}

@app.get("/api/tasks")
def get_tasks():
    return execute_tool("list_tasks", {})

@app.post("/api/tasks")
def add_task(task: TaskCreate):
    try:
        return execute_tool("create_task", task.model_dump())
    except ToolError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@app.patch("/api/tasks/{task_id}/complete")
def complete_task(task_id: int):
    with db_session() as db:
        cur = db.execute("UPDATE tasks SET status='done' WHERE id=?", (task_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Task not found")
        row = db.execute("SELECT id,title,due_at,status,created_at FROM tasks WHERE id=?", (task_id,)).fetchone()
        return {"task": dict(row)}

@app.get("/api/notes")
def get_notes():
    with db_session() as db:
        rows = db.execute("SELECT id,title,content,created_at FROM notes ORDER BY id DESC LIMIT 200").fetchall()
        return {"notes": [dict(r) for r in rows]}

@app.post("/api/notes")
def add_note(note: NoteCreate):
    try:
        return execute_tool("create_note", note.model_dump())
    except ToolError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

@app.get("/api/memories")
def get_memories():
    with db_session() as db:
        rows = db.execute("SELECT id,content,created_at FROM memories ORDER BY id DESC LIMIT 200").fetchall()
        return {"memories": [dict(r) for r in rows]}

@app.post("/api/memories")
def add_memory(memory: MemoryCreate):
    with db_session() as db:
        cur = db.execute("INSERT INTO memories(content) VALUES(?)", (memory.content.strip(),))
        row = db.execute("SELECT id,content,created_at FROM memories WHERE id=?", (cur.lastrowid,)).fetchone()
        return {"memory": dict(row)}

@app.delete("/api/memories/{memory_id}")
def delete_memory(memory_id: int):
    with db_session() as db:
        cur = db.execute("DELETE FROM memories WHERE id=?", (memory_id,))
        if cur.rowcount == 0:
            raise HTTPException(status_code=404, detail="Memory not found")
        return {"deleted": True, "id": memory_id}

@app.post("/api/tools/execute")
def tool_endpoint(request: ToolRequest):
    # This endpoint exposes only registered, application-scoped tools. Do not expose publicly without auth.
    try:
        return {"ok": True, "tool": request.name, "result": execute_tool(request.name, request.arguments)}
    except ToolError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
