import os
import tempfile
from pathlib import Path

# Use an isolated database for tests before importing the application modules.
_tmp = tempfile.TemporaryDirectory()
os.environ["DATABASE_PATH"] = str(Path(_tmp.name) / "test.db")
os.environ["GROQ_API_KEY"] = ""
from app.tools import execute_tool, ToolError
from app.main import health

def test_task_create_and_list():
    created = execute_tool("create_task", {"title": "Study physics", "due_at": "18:00"})
    assert created["task"]["title"] == "Study physics"
    assert created["task"]["status"] == "open"
    assert any(t["title"] == "Study physics" for t in execute_tool("list_tasks", {})["tasks"])

def test_note_create():
    result = execute_tool("create_note", {"title": "Idea", "content": "Test note"})
    assert result["note"]["content"] == "Test note"

def test_reject_unknown_tool():
    try:
        execute_tool("run_shell", {"cmd": "echo unsafe"})
        assert False, "Expected unknown tool rejection"
    except ToolError as exc:
        assert "not available" in str(exc)

def test_validate_task_title():
    try:
        execute_tool("create_task", {"title": "  "})
        assert False, "Expected invalid title rejection"
    except ToolError:
        pass

def test_health_reports_demo_mode():
    response = health()
    assert response["status"] == "ok"
    assert response["mode"] == "demo"
