# Platform capability matrix

| Capability | Web dashboard | Android companion | Notes |
|---|---|---|---|
| Text conversation | Yes, through backend | Scaffold only; API connection is next step | Backend requires network reachability |
| Speech input | Browser support dependent | Android system recognizer intent | User-triggered; permission required |
| Spoken output | Browser speech synthesis | Not wired yet | Browser voice quality varies by OS/browser |
| Stop current speech | Yes | N/A until TTS added | Cancels browser synthesis |
| Persist tasks and notes | Yes, SQLite backend | Not wired yet | Backend owns persistence |
| Calendar access | Not configured | Not configured | Requires calendar provider/API and permissions |
| Launch URLs/apps | Browser navigation only | Can hand off URLs to Android | OS decides the target app |
| Incoming call detection/answer | No | Not implemented | Restricted APIs/default dialer role/permissions may apply |
| SMS sending | No | Not implemented | Requires user-approved supported messaging integration; avoid silent sending |
| Wake word/background listening | No | No | Requires separate on-device engine, battery/privacy design, and platform compliance |
| Arbitrary system settings | No | No | Only documented platform APIs; do not bypass OS controls |

Android emulator URL `10.0.2.2` points to the host machine. A physical phone needs a reachable LAN/HTTPS backend address and suitable network security configuration; the placeholder dashboard URL should be changed accordingly.
