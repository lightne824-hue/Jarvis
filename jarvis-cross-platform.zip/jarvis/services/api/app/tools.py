"""Explicit allowlist of safe, application-scoped actions. Never execute model-generated code."""
from .db import db_session

class ToolError(ValueError):
    pass

def list_tasks(_: dict) -> dict:
    with db_session() as db:
        rows = db.execute("SELECT id,title,due_at,status,created_at FROM tasks ORDER BY id DESC LIMIT 100").fetchall()
        return {"tasks": [dict(r) for r in rows]}

def create_task(args: dict) -> dict:
    title = args.get("title")
    if not isinstance(title, str) or not title.strip() or len(title) > 300:
        raise ToolError("A task title between 1 and 300 characters is required.")
    due_at = args.get("due_at")
    if due_at is not None and (not isinstance(due_at, str) or len(due_at) > 80):
        raise ToolError("due_at must be a short date/time string.")
    with db_session() as db:
        cur = db.execute("INSERT INTO tasks(title,due_at) VALUES(?,?)", (title.strip(), due_at))
        row = db.execute("SELECT id,title,due_at,status,created_at FROM tasks WHERE id=?", (cur.lastrowid,)).fetchone()
        return {"task": dict(row)}

def create_note(args: dict) -> dict:
    title, content = args.get("title"), args.get("content", "")
    if not isinstance(title, str) or not title.strip() or len(title) > 300:
        raise ToolError("A note title between 1 and 300 characters is required.")
    if not isinstance(content, str) or len(content) > 20000:
        raise ToolError("Note content must be text under 20,000 characters.")
    with db_session() as db:
        cur = db.execute("INSERT INTO notes(title,content) VALUES(?,?)", (title.strip(), content))
        row = db.execute("SELECT id,title,content,created_at FROM notes WHERE id=?", (cur.lastrowid,)).fetchone()
        return {"note": dict(row)}

TOOL_REGISTRY = {
    "list_tasks": {"handler": list_tasks, "risk": "low", "description": "List saved tasks", "schema": {"type": "object", "properties": {}, "additionalProperties": False}},
    "create_task": {"handler": create_task, "risk": "low", "description": "Create a task in JARVIS", "schema": {"type": "object", "properties": {"title": {"type": "string"}, "due_at": {"type": ["string", "null"]}}, "required": ["title"], "additionalProperties": False}},
    "create_note": {"handler": create_note, "risk": "low", "description": "Save a note in JARVIS", "schema": {"type": "object", "properties": {"title": {"type": "string"}, "content": {"type": "string"}}, "required": ["title", "content"], "additionalProperties": False}},
}

def execute_tool(name: str, arguments: dict) -> dict:
    tool = TOOL_REGISTRY.get(name)
    if not tool:
        raise ToolError(f"Tool '{name}' is not available.")
    if not isinstance(arguments, dict):
        raise ToolError("Tool arguments must be an object.")
    return tool["handler"](arguments)
