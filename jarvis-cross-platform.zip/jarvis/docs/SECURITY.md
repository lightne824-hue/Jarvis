# Security and privacy notes

- Any API credentials pasted into a chat, issue, source file, screenshot, or commit should be considered exposed. Revoke/rotate them and use server-side environment variables.
- The web application is a local development dashboard. It is not production-hardened: no user authentication, no CSRF strategy, and no deployment TLS are configured. Do not expose the API to the public internet as-is.
- CORS is restricted to the configured development origins. Change it deliberately for a real deployment.
- The LLM can invoke only a short allowlist of application-scoped task/note tools. No arbitrary shell, filesystem, or OS execution is available.
- The `/api/tools/execute` endpoint is for local development and must be protected by authentication/authorization before network exposure.
- SQLite persists conversations, tasks, notes, and memories on the backend host. Provide retention, export, and delete controls before multi-user/production use.
- Do not place secrets in frontend environment variables prefixed with `VITE_`; these are bundled into client assets.
- Microphone use is user initiated. The browser requests permission through its speech-recognition implementation. Android requests `RECORD_AUDIO` at runtime and launches the system speech interface.
