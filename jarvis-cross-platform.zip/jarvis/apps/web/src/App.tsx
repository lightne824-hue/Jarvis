import { useCallback, useEffect, useRef, useState } from 'react';
import { Activity, AudioLines, Bell, BrainCircuit, CalendarDays, Check, ChevronRight, CircleHelp, Command, Cpu, Database, FileText, Gauge, Globe2, Headphones, LayoutDashboard, Mic, MicOff, Monitor, Moon, Plus, Search, Send, Settings, ShieldCheck, Sparkles, Square, Terminal, Volume2, Workflow, Zap } from 'lucide-react';

type Task = {id:number; title:string; due_at:string|null; status:'open'|'done'; created_at:string};
type Note = {id:number; title:string; content:string; created_at:string};
type ChatItem = {role:'user'|'assistant'; content:string};
type Status = 'IDLE'|'LISTENING'|'THINKING'|'EXECUTING_TOOL'|'SPEAKING'|'ERROR';
const API = (import.meta as any).env?.VITE_API_BASE_URL || 'http://127.0.0.1:8000';

function App() {
  const [status, setStatus] = useState<Status>('IDLE');
  const [health, setHealth] = useState<{mode:string;llm_configured:boolean}|null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [messages, setMessages] = useState<ChatItem[]>([{role:'assistant',content:'Good morning. JARVIS is online. What would you like me to take care of?'}]);
  const [draft, setDraft] = useState('');
  const [active, setActive] = useState('Command Center');
  const [query, setQuery] = useState('');
  const [toast, setToast] = useState('');
  const [showChat, setShowChat] = useState(false);
  const [muted, setMuted] = useState(false);
  const [listeningSupported, setListeningSupported] = useState(true);
  const recognition = useRef<any>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const refresh = useCallback(async () => {
    try {
      const [h,t,n] = await Promise.all([fetch(`${API}/health`), fetch(`${API}/api/tasks`), fetch(`${API}/api/notes`)]);
      if (h.ok) setHealth(await h.json());
      if (t.ok) setTasks((await t.json()).tasks || []);
      if (n.ok) setNotes((await n.json()).notes || []);
    } catch { setHealth(null); }
  }, []);
  useEffect(() => { void refresh(); const id = window.setInterval(() => void refresh(), 30000); return () => window.clearInterval(id); }, [refresh]);
  useEffect(() => { bottomRef.current?.scrollIntoView({behavior:'smooth'}); }, [messages, showChat]);
  useEffect(() => { const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition; setListeningSupported(Boolean(SR)); }, []);

  const speak = (text:string) => {
    if (muted || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.02;
    utterance.pitch = 0.92;
    utterance.onstart = () => setStatus('SPEAKING');
    utterance.onend = () => setStatus('IDLE');
    utterance.onerror = () => setStatus('IDLE');
    window.speechSynthesis.speak(utterance);
  };

  const sendMessage = async (raw?:string) => {
    const text = (raw ?? draft).trim(); if (!text || status === 'THINKING') return;
    setDraft(''); setShowChat(true); setMessages(prev => [...prev, {role:'user',content:text}]); setStatus('THINKING');
    try {
      const response = await fetch(`${API}/api/chat`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,history:messages.slice(-12)})});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'The API request failed.');
      const reply = String(data.reply || 'No response received.');
      setMessages(prev => [...prev,{role:'assistant',content:reply}]);
      if (data.actions?.length) setStatus('EXECUTING_TOOL');
      speak(reply); await refresh();
      if (data.mode === 'demo') setToast('Demo mode · Configure GROQ_API_KEY on the backend for live AI.');
      else if (data.actions?.length) setToast(`Completed ${data.actions.filter((a:any)=>a.status==='success').length} tool action(s).`);
    } catch (e) {
      const error = e instanceof Error ? e.message : 'Connection error';
      setMessages(prev => [...prev,{role:'assistant',content:`I couldn't complete that request. ${error} Check that the JARVIS API is running.`}]); setStatus('ERROR'); setToast('Backend connection unavailable');
    } finally { window.setTimeout(() => setStatus(s => s === 'ERROR' ? 'IDLE' : s === 'EXECUTING_TOOL' ? 'IDLE' : s), 500); }
  };

  const startListening = () => {
    const SR = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SR) { setToast('Speech recognition is not supported in this browser. Try Chrome or use the text command bar.'); return; }
    if (status === 'LISTENING') { recognition.current?.stop(); setStatus('IDLE'); return; }
    window.speechSynthesis?.cancel();
    const instance = new SR(); recognition.current = instance; instance.lang = 'en-US'; instance.interimResults = true; instance.continuous = false;
    instance.onstart = () => setStatus('LISTENING');
    instance.onresult = (event:any) => { const transcript = Array.from(event.results).map((r:any)=>r[0].transcript).join(''); setDraft(transcript); if (event.results[event.results.length-1].isFinal) { setDraft(''); void sendMessage(transcript); } };
    instance.onerror = (event:any) => { setStatus('IDLE'); setToast(`Microphone error: ${event.error || 'unknown error'}`); };
    instance.onend = () => setStatus(s => s === 'LISTENING' ? 'IDLE' : s);
    try { instance.start(); } catch { setToast('Microphone could not start. Check browser permission.'); setStatus('IDLE'); }
  };
  const stopSpeech = () => { recognition.current?.stop(); window.speechSynthesis?.cancel(); setStatus('IDLE'); };
  const createTask = async () => { const title = window.prompt('Task title'); if (!title?.trim()) return; try { const r = await fetch(`${API}/api/tasks`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.trim()})}); if(!r.ok) throw new Error('Could not save task'); await refresh(); setToast('Task saved.'); } catch { setToast('Could not save task. Check the API connection.'); } };
  const completeTask = async (id:number) => { try { const r = await fetch(`${API}/api/tasks/${id}/complete`,{method:'PATCH'}); if(!r.ok) throw new Error(); await refresh(); } catch { setToast('Could not update task.'); } };
  const createNote = async () => { const title = window.prompt('Note title'); if (!title?.trim()) return; const content = window.prompt('Note content') || ''; try { const r=await fetch(`${API}/api/notes`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({title:title.trim(),content})}); if(!r.ok) throw new Error(); await refresh(); setToast('Note saved.'); } catch { setToast('Could not save note.'); } };
  const nav = [{name:'Command Center',icon:LayoutDashboard},{name:'AI Core',icon:BrainCircuit},{name:'Agents',icon:Workflow},{name:'Tasks',icon:Check,count:tasks.filter(t=>t.status==='open').length},{name:'Calendar',icon:CalendarDays},{name:'Memory',icon:Database,count:notes.length},{name:'Conversations',icon:AudioLines},{name:'Knowledge Base',icon:Globe2},{name:'Tools & Skills',icon:Zap},{name:'Workflows',icon:Terminal}];
  const openTasks = tasks.filter(t=>t.status==='open');
  const filteredTasks = openTasks.filter(t=>t.title.toLowerCase().includes(query.toLowerCase()));
  const stateLabel:Record<Status,string>={IDLE:'Systems nominal',LISTENING:'Listening for command',THINKING:'Processing request',EXECUTING_TOOL:'Executing action',SPEAKING:'Speaking',ERROR:'Action failed'};

  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-orb"><span/></div><div><div className="brand-name">JARVIS</div><div className="brand-sub">COMMAND CENTER</div></div></div>
      <div className="nav-list">{nav.map(({name,icon:Icon,count})=><button key={name} onClick={()=>{setActive(name); if(name==='Conversations')setShowChat(true);}} className={`nav-item ${active===name?'active':''}`}><Icon size={17}/><span>{name}</span>{count!==undefined&&count>0&&<b>{count}</b>}</button>)}</div>
      <div className="sidebar-spacer"/>
      <div className="voice-card"><div className="panel-label">VOICE STATUS <span className={`live-dot ${status==='LISTENING'?'pulse':''}`}/></div><div className={`waveform ${status==='LISTENING'||status==='SPEAKING'?'moving':''}`}>{Array.from({length:31},(_,i)=><i key={i} style={{height:`${8+Math.abs(Math.sin(i*1.8))*20+(i%5)*2}px`}}/>)}</div><div className="voice-state">{status==='LISTENING'?'Listening…':status==='SPEAKING'?'Speaking…':status==='THINKING'?'Processing…':'Standing by'}</div><button className={`mic-button ${status==='LISTENING'?'listening':''}`} onClick={startListening} aria-label="Toggle microphone"><Mic size={25}/></button><div className="muted-note">{listeningSupported?'Tap to speak':'Speech input unavailable'}</div></div>
      <button className="focus-button" onClick={()=>{setShowChat(true);setToast('Focus mode enabled for this session.');}}><Zap size={15}/> Focus Mode</button>
      <div className="side-footer"><ShieldCheck size={14}/> Local-first controls</div>
    </aside>

    <main className="main-area">
      <header className="topbar"><div className="system-status"><span className="status-light"/><span>{health?.mode==='live'?'AI PROVIDER CONNECTED':health?.mode==='demo'?'DEMO MODE':'API DISCONNECTED'}</span><b>{health?.mode==='live'?'LIVE':health?.mode==='demo'?'READY':'OFFLINE'}</b></div><div className="clock"><div>{new Date().toLocaleDateString(undefined,{weekday:'long',day:'2-digit',month:'long',year:'numeric'})}</div><strong>{new Date().toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true})}</strong></div><div className="top-actions"><div className="search"><Search size={15}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search tasks…"/></div><button title="Notifications" onClick={()=>setToast('No new system notifications.')}><Bell size={17}/></button><button title="Settings" onClick={()=>setActive('Settings')}><Settings size={17}/></button><div className="operator"><div className="operator-avatar"><Command size={18}/></div><div><b>Operator</b><small>Commander</small></div></div></div></header>

      <div className="dashboard-grid">
        <section className="panel core-overview"><div className="panel-title">AI CORE OVERVIEW</div><StatusRow icon={<BrainCircuit/>} title="AI Core" value={health?.mode==='live'?'Active':'Demo mode'} tone={health?.mode==='live'?'green':'cyan'}/><StatusRow icon={<Database/>} title="Memory" value={`${notes.length} Notes · ${tasks.length} Tasks`} tone="blue"/><StatusRow icon={<Mic/>} title="Voice" value={listeningSupported?'Browser supported':'Unavailable'} tone="green"/><StatusRow icon={<Workflow/>} title="Agents" value="3 Modules ready" tone="purple"/><StatusRow icon={<Sparkles/>} title="LLM Provider" value={health?.llm_configured?'Groq connected':'Not configured'} tone="amber"/><StatusRow icon={<ShieldCheck/>} title="System" value={health?'Operational':'API offline'} tone={health?'green':'red'}/></section>

        <section className="hero-core panel"><div className="starfield"/><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/><div className="core-sphere"><div className="sphere-grid"/><div className="sphere-center"><span>JARVIS</span><small>AI CORE</small><em>v0.1.0</em></div></div><div className="hero-foot"><span className="cyan-dot"/> PERSONAL INTELLIGENCE SYSTEM <span className="hero-sep">/</span> {stateLabel[status].toUpperCase()}</div></section>

        <section className="panel intelligence"><div className="panel-heading"><div className="panel-title">LIVE INTELLIGENCE FEED</div><span className="live-pill"><i/> LIVE</span></div><FeedItem icon={<Activity/>} title={health?'API health check complete':'Waiting for backend'} sub={health?`JARVIS API · ${health.mode} mode`:'Start the backend service'} tone={health?'cyan':'amber'} tag={health?'INFO':'WARN'}/><FeedItem icon={<Check/>} title={`${openTasks.length} open tasks`} sub={openTasks.length?'Review and complete your pending tasks':'You are all caught up'} tone="amber" tag="TASKS"/><FeedItem icon={<Database/>} title={`${notes.length} saved notes`} sub="Stored in local SQLite database" tone="purple" tag="MEMORY"/><FeedItem icon={<Headphones/>} title={stateLabel[status]} sub={status==='IDLE'?'Awaiting your next instruction':'Voice and action state'} tone="cyan" tag="SYSTEM"/><button className="text-link" onClick={()=>setShowChat(true)}>Open conversation <ChevronRight size={14}/></button></section>

        <section className="panel agents-panel"><div className="panel-heading"><div className="panel-title">ACTIVE AGENTS</div><button className="text-link" onClick={()=>setActive('Agents')}>View all <ChevronRight size={13}/></button></div><div className="agent-grid"><Agent icon={<Terminal/>} name="Coding Agent" state="Standby" tone="green"/><Agent icon={<Search/>} name="Research Agent" state="Ready" tone="cyan"/><Agent icon={<Database/>} name="Memory Agent" state="Active" tone="purple"/><Agent icon={<Globe2/>} name="Browser Agent" state="Not configured" tone="amber"/><Agent icon={<Check/>} name="Task Agent" state="Operational" tone="blue"/><Agent icon={<Cpu/>} name="System Agent" state="Limited access" tone="green"/></div></section>

        <section className="panel timeline"><div className="panel-heading"><div className="panel-title">MISSION TIMELINE</div><span className="subtle">TODAY</span></div><div className="timeline-list"><Timeline time="NOW" title="JARVIS system status" detail={health?'API health verified':'API connection pending'} done={!!health}/><Timeline time="NEXT" title="Review pending tasks" detail={`${openTasks.length} task(s) awaiting action`} done={openTasks.length===0}/><Timeline time="READY" title="Voice command interface" detail={listeningSupported?'Browser speech recognition available':'Text commands available'} done={listeningSupported}/><Timeline time="LATER" title="Android companion" detail="Native integration scaffold" done={false}/></div><button className="text-link" onClick={()=>setActive('Tasks')}>View task list <ChevronRight size={13}/></button></section>

        <section className="panel quick-commands"><div className="panel-title">QUICK COMMANDS</div><button className="quick-command" onClick={createTask}><Plus size={16}/> Create New Task</button><button className="quick-command" onClick={()=>{setActive('Calendar');setToast('Calendar integration is not configured yet.');}}><CalendarDays size={16}/> Open Calendar</button><button className="quick-command" onClick={startListening}><Mic size={16}/> Start Voice Chat</button><button className="quick-command" onClick={createNote}><FileText size={16}/> Save a Note</button><button className="quick-command" onClick={()=>{setShowChat(true);setDraft('Help me plan my next tasks');}}><Workflow size={16}/> Plan a Workflow</button></section>

        <section className="panel monitor"><div className="panel-title">SYSTEM MONITOR</div><div className="monitor-circles"><GaugeCircle label="API" value={health?'OK':'OFF'} percent={health?100:18}/><GaugeCircle label="TASKS" value={String(openTasks.length)} percent={Math.min(openTasks.length*12,100)}/><GaugeCircle label="VOICE" value={listeningSupported?'READY':'N/A'} percent={listeningSupported?78:10}/></div><div className="monitor-note"><span className="status-light"/> No hardware telemetry available from this web browser</div></section>

        <section className="panel memory-insights"><div className="panel-title">MEMORY INSIGHTS</div><div className="memory-body"><div className="memory-graph"><svg viewBox="0 0 280 110" preserveAspectRatio="none"><polyline points="2,77 26,48 49,59 74,31 95,51 121,40 145,67 166,21 188,49 210,43 233,75 254,59 278,67"/><g>{[[2,77],[26,48],[49,59],[74,31],[95,51],[121,40],[145,67],[166,21],[188,49],[210,43],[233,75],[254,59],[278,67]].map(([x,y],i)=><circle key={i} cx={x} cy={y} r="3"/>)}</g></svg><span>Persistent storage</span></div><div className="memory-stats"><b>{notes.length}<small>Notes</small></b><b>{tasks.length}<small>Tasks</small></b><b>{messages.length}<small>Session messages</small></b></div></div><button className="text-link" onClick={()=>setActive('Memory')}>Manage memory <ChevronRight size={13}/></button></section>

        <section className="panel llm-status"><div className="panel-heading"><div className="panel-title">PROVIDER STATUS</div><span className={`provider-badge ${health?.llm_configured?'green':''}`}>{health?.llm_configured?'1 Connected':'Demo'}</span></div><div className="provider-grid"><Provider name="Groq" status={health?.llm_configured?'Connected':'Needs API key'} tone={health?.llm_configured?'green':'amber'}/><Provider name="Browser Speech" status={listeningSupported?'Available':'Unsupported'} tone={listeningSupported?'cyan':'amber'}/><Provider name="Speech Synthesis" status={'speechSynthesis' in window?'Available':'Unsupported'} tone={'speechSynthesis' in window?'green':'amber'}/><Provider name="Calendar" status="Not configured" tone="muted"/><Provider name="Android Bridge" status="Not connected" tone="muted"/><Provider name="Web Search" status="Not configured" tone="muted"/></div><button className="text-link" onClick={()=>setActive('Settings')}>Manage integrations <ChevronRight size={13}/></button></section>
      </div>

      {active==='Tasks'&&<div className="overlay-panel"><div className="panel-heading"><h2>Task manager</h2><button onClick={()=>setActive('Command Center')}><Square size={15}/></button></div>{filteredTasks.length?filteredTasks.map(t=><div className="task-line" key={t.id}><button className="check-task" onClick={()=>void completeTask(t.id)}><Check size={14}/></button><div><b>{t.title}</b><small>{t.due_at||'No due date'} · {t.status}</small></div></div>):<p className="empty">No open tasks. Create one using Quick Commands.</p>}</div>}
      {active==='Memory'&&<div className="overlay-panel"><div className="panel-heading"><h2>Saved notes</h2><button onClick={createNote}><Plus size={16}/> Add</button></div>{notes.length?notes.map(n=><div className="note-line" key={n.id}><FileText size={16}/><div><b>{n.title}</b><p>{n.content||'No content'}</p></div></div>):<p className="empty">No notes saved yet.</p>}<p className="privacy-hint"><ShieldCheck size={14}/> Stored on the configured backend database.</p></div>}
      {active==='Settings'&&<div className="overlay-panel"><div className="panel-heading"><h2>System settings</h2><button onClick={()=>setActive('Command Center')}>Close</button></div><div className="setting-row"><div><b>API connection</b><small>{health?'Backend reachable':'Backend unavailable'}</small></div><button onClick={()=>void refresh()}>Recheck</button></div><div className="setting-row"><div><b>Voice output</b><small>Browser speech synthesis</small></div><button onClick={()=>setMuted(v=>!v)}>{muted?'Unmute':'Mute'}</button></div><div className="setting-row"><div><b>Speech interruption</b><small>Stop current audio playback</small></div><button onClick={stopSpeech}>Stop audio</button></div><p className="privacy-hint"><ShieldCheck size={14}/> Server keys must remain in the backend environment. Never paste them into browser settings.</p></div>}

      {showChat&&<div className="chat-drawer"><div className="chat-header"><div><span className="cyan-dot"/> <b>Talk to JARVIS</b><small> Contextual assistant</small></div><div className="chat-controls"><button title="Stop speech" onClick={stopSpeech}><Square size={15}/></button><button title="Close conversation" onClick={()=>setShowChat(false)}>×</button></div></div><div className="chat-messages">{messages.map((m,i)=><div key={i} className={`message ${m.role}`}><span>{m.role==='assistant'?'J':'YOU'}</span><p>{m.content}</p></div>)}<div ref={bottomRef}/></div><form className="chat-input" onSubmit={e=>{e.preventDefault();void sendMessage();}}><button type="button" onClick={startListening} className={status==='LISTENING'?'active-mic':''} title="Voice input"><Mic size={18}/></button><input value={draft} onChange={e=>setDraft(e.target.value)} placeholder="Give JARVIS a command…"/><button type="submit" disabled={!draft.trim()||status==='THINKING'} title="Send"><Send size={17}/></button></form></div>}

      <footer className="bottom-bar"><div className="environment"><div><Globe2 size={14}/><span>Location<br/><b>Not configured</b></span></div><div><Activity size={14}/><span>System<br/><b>{health?'API reachable':'Offline'}</b></span></div><div><ShieldCheck size={14}/><span>Privacy<br/><b>Permission-gated</b></span></div></div><button className={`talk-button ${status==='LISTENING'?'talk-listening':''}`} onClick={startListening}><AudioLines size={21}/><span><b>{status==='LISTENING'?'LISTENING…':'TALK TO JARVIS'}</b><small>{stateLabel[status]}</small></span><AudioLines size={21}/></button><button className="briefing-button" onClick={()=>{setShowChat(true);void sendMessage('Give me a concise executive briefing based on my saved tasks and notes.');}}><Zap size={14}/> Executive Briefing</button></footer>
      {toast&&<div className="toast" role="status"><CircleHelp size={16}/>{toast}<button onClick={()=>setToast('')}>×</button></div>}
    </main>
  </div>;
}

function StatusRow({icon,title,value,tone}:{icon:React.ReactNode;title:string;value:string;tone:string}){return <div className="status-row"><div className={`status-icon ${tone}`}>{icon}</div><div><b>{title}</b><small>{value}</small></div></div>}
function FeedItem({icon,title,sub,tone,tag}:{icon:React.ReactNode;title:string;sub:string;tone:string;tag:string}){return <div className="feed-item"><div className={`feed-icon ${tone}`}>{icon}</div><div className="feed-copy"><b>{title}</b><small>{sub}</small></div><span className={`feed-tag ${tone}`}>{tag}</span></div>}
function Agent({icon,name,state,tone}:{icon:React.ReactNode;name:string;state:string;tone:string}){return <div className="agent"><div className={`agent-icon ${tone}`}>{icon}</div><div><b>{name}</b><small><i className={tone}/> {state}</small></div><div className="agent-bars">{Array.from({length:10},(_,i)=><i key={i} style={{height:`${4+(i*7)%13}px`}}/>)}</div></div>}
function Timeline({time,title,detail,done}:{time:string;title:string;detail:string;done:boolean}){return <div className="timeline-item"><div className="timeline-time">{time}</div><div className="timeline-mark"><i className={done?'done':''}/></div><div className="timeline-copy"><b>{title}</b><small>{detail}</small></div><span className={done?'done-label':'pending-label'}>{done?'VERIFIED':'PENDING'}</span></div>}
function GaugeCircle({label,value,percent}:{label:string;value:string;percent:number}){return <div className="gauge"><div className="gauge-ring" style={{'--percent':`${percent}%`} as React.CSSProperties}><div><b>{value}</b></div></div><small>{label}</small></div>}
function Provider({name,status,tone}:{name:string;status:string;tone:string}){return <div className="provider"><span className={`provider-icon ${tone}`}><Cpu size={14}/></span><div><b>{name}</b><small>{status}</small></div><i className={`provider-dot ${tone}`}/></div>}
export default App;
