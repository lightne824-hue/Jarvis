package com.novacart.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF061321)
private val Cyan = Color(0xFF48DFFF)
private val Muted = Color(0xFF8CAFC1)

class MainActivity : ComponentActivity() {
    private var transcriptHandler: ((String) -> Unit)? = null
    private var tts: TextToSpeech? = null
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognizer() else Toast.makeText(this, "Microphone permission is required for voice input.", Toast.LENGTH_LONG).show()
    }
    private val speechResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            if (text.isNotBlank()) transcriptHandler?.invoke(text)
        }
    }

    override fun onDestroy() { super.onDestroy(); tts?.stop(); tts?.shutdown() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var transcript by remember { mutableStateOf("Ready for your command.") }
            tts = TextToSpeech(this) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault() }
            transcriptHandler = { text -> transcript = "You: $text\nJARVIS is thinking…"; sendToBackend(text) }
            currentReplyCallback = { reply -> transcript = reply }
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Navy, surface = Color(0xFF0A1C2C))) {
                Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
                    Column(
                        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0C2940), Navy, Color(0xFF030912)))).padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("J A R V I S", color = Cyan, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                            Text("PERSONAL AI COMPANION", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(modifier = Modifier.size(190.dp).background(Color(0xFF0A263D), CircleShape), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("JARVIS", color = Cyan, fontSize = 28.sp, letterSpacing = 5.sp)
                                    Text("AI CORE", color = Muted, fontSize = 12.sp, letterSpacing = 3.sp)
                                }
                            }
                            Spacer(Modifier.height(28.dp))
                            Text(transcript, color = Color(0xFFD9EDF6), fontSize = 15.sp)
                            Spacer(Modifier.height(18.dp))
                            Button(onClick = { requestVoiceInput() }, shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D526B))) {
                                Text("  🎙  TALK TO JARVIS  ", color = Color.White, modifier = Modifier.padding(vertical = 7.dp))
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton(onClick = { openWebDashboard() }, shape = RoundedCornerShape(12.dp)) {
                                Text("Open command center", color = Cyan)
                            }
                        }
                        Text("Voice recognition uses Android's supported speech interface. No always-on listening.", color = Muted, fontSize = 10.sp)
                    }
                }
            }
        }
    }

    private fun requestVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) launchSpeechRecognizer()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun launchSpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak your command to JARVIS")
        }
        try { speechResult.launch(intent) } catch (_: Exception) {
            Toast.makeText(this, "No compatible speech recognition service is installed.", Toast.LENGTH_LONG).show()
        }
    }

    private fun sendToBackend(message: String) {
        Thread {
            var reply = "I couldn't reach the JARVIS backend. Check that the API is running and reachable from this device."
            try {
                val connection = (URL("${BuildConfig.API_BASE_URL}/api/chat").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 8000
                    readTimeout = 35000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(JSONObject().put("message", message).put("history", org.json.JSONArray()).toString())
                }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val body = stream.bufferedReader().use { it.readText() }
                if (connection.responseCode in 200..299) reply = JSONObject(body).optString("reply", "No response received.")
                else reply = "JARVIS API error (${connection.responseCode}). Check the backend logs."
                connection.disconnect()
            } catch (_: Exception) { }
            runOnUiThread {
                transcriptHandler = { }
                val speakable = reply
                tts?.speak(speakable, TextToSpeech.QUEUE_FLUSH, null, "jarvis-response")
                // Update the Compose state via the transcript callback set during composition.
                currentReplyCallback?.invoke(speakable)
            }
        }.start()
    }

    private var currentReplyCallback: ((String) -> Unit)? = null

    private fun openWebDashboard() {
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("http://10.0.2.2:5173"))
        try { startActivity(intent) } catch (_: Exception) { Toast.makeText(this, "Could not open the dashboard URL.", Toast.LENGTH_LONG).show() }
    }
}
