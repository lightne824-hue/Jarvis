# JARVIS Android companion scaffold

This is the native Android integration starting point. Open this folder in Android Studio and let it generate/sync a Gradle project using a current stable Android Gradle Plugin. The Kotlin Compose screen is intentionally modest: real calling, SMS, notification access, and background microphone behavior must be added only through supported APIs and explicit user permissions.

Initial capabilities in this scaffold: native Compose UI, microphone permission request, Android speech recognizer launch, and safe opening of a web URL. It does not auto-answer calls or continuously listen in the background.
