from pydantic import BaseModel, Field
from typing import Literal

class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)

class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: list[ChatMessage] = Field(default_factory=list, max_length=30)

class ChatResponse(BaseModel):
    reply: str
    provider: str
    mode: Literal["live", "demo"]
    actions: list[dict] = Field(default_factory=list)

class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    due_at: str | None = Field(default=None, max_length=80)

class NoteCreate(BaseModel):
    title: str = Field(min_length=1, max_length=300)
    content: str = Field(default="", max_length=20000)

class MemoryCreate(BaseModel):
    content: str = Field(min_length=1, max_length=3000)

class ToolRequest(BaseModel):
    name: str
    arguments: dict = Field(default_factory=dict)
